import { useState } from "react";

// ── Mock data ────────────────────────────────────────────────────────────────

const MOCK_TICKETS = [
  {
    id: "TICKET-12",
    title: "Add biometric login (Face ID / Touch ID)",
    priority: "High",
    status: "To-Do",
    label: "ai_dev",
    created: "2 hours ago",
    criteria: 4,
  },
  {
    id: "TICKET-11",
    title: "Show progress bar during file upload",
    priority: "Medium",
    status: "In Progress",
    label: "ai_dev",
    created: "Yesterday",
    criteria: 3,
  },
  {
    id: "TICKET-10",
    title: "Send push notification on new message",
    priority: "High",
    status: "In Review",
    label: "ai_dev",
    created: "3 days ago",
    criteria: 5,
  },
];

const MOCK_PRS = [
  {
    id: "PR #8",
    ticket: "TICKET-10",
    title: "Send push notification on new message",
    branch: "feature/TICKET-10-push-notifications",
    ci: "passing",
    aiReview: "APPROVED",
    author: "Claude Code",
    updated: "1 hour ago",
  },
  {
    id: "PR #7",
    ticket: "TICKET-9",
    title: "Dark mode toggle in settings",
    branch: "feature/TICKET-9-dark-mode",
    ci: "passing",
    aiReview: "NEEDS CHANGES",
    author: "Claude Code",
    updated: "4 hours ago",
  },
  {
    id: "PR #6",
    ticket: "TICKET-8",
    title: "Fix crash on empty search results",
    branch: "fix/TICKET-8-empty-search-crash",
    ci: "running",
    aiReview: "pending",
    author: "Claude Code",
    updated: "12 min ago",
  },
];

const MOCK_BUILDS = [
  { version: "v0.3.1", date: "2 days ago", ios: "✓", android: "✓", triggered: "Pierre-Andre" },
  { version: "v0.3.0", date: "5 days ago", ios: "✓", android: "✓", triggered: "Pierre-Andre" },
  { version: "v0.2.9", date: "1 week ago", ios: "✗", android: "✓", triggered: "Pierre-Andre" },
];

// ── Helpers ──────────────────────────────────────────────────────────────────

const Badge = ({ label, color }) => {
  const colors = {
    green: "bg-emerald-100 text-emerald-700",
    yellow: "bg-amber-100 text-amber-700",
    red: "bg-red-100 text-red-700",
    blue: "bg-blue-100 text-blue-700",
    gray: "bg-slate-100 text-slate-600",
    indigo: "bg-indigo-100 text-indigo-700",
  };
  return (
    <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${colors[color] || colors.gray}`}>
      {label}
    </span>
  );
};

const CiDot = ({ status }) => {
  if (status === "passing") return <span className="flex items-center gap-1 text-xs text-emerald-600 font-medium"><span className="w-2 h-2 rounded-full bg-emerald-500 inline-block" />Passing</span>;
  if (status === "running") return <span className="flex items-center gap-1 text-xs text-amber-600 font-medium"><span className="w-2 h-2 rounded-full bg-amber-400 inline-block animate-pulse" />Running</span>;
  return <span className="flex items-center gap-1 text-xs text-red-600 font-medium"><span className="w-2 h-2 rounded-full bg-red-500 inline-block" />Failed</span>;
};

const priorityColor = (p) => ({ High: "red", Medium: "yellow", Low: "gray" }[p] || "gray");
const reviewColor = (r) => ({ APPROVED: "green", "NEEDS CHANGES": "yellow", "CRITICAL ISSUES": "red", pending: "gray" }[r] || "gray");

// ── Setup Wizard ─────────────────────────────────────────────────────────────

function SetupWizard({ onDone }) {
  const [step, setStep] = useState(0);
  const [vals, setVals] = useState({ planeKey: "", workspace: "", projectId: "", githubToken: "", repo: "", anthropicKey: "" });

  const steps = [
    {
      icon: "🗂️",
      title: "Connect Plane.so",
      desc: "Plane is where your tickets live. Claude reads them via API.",
      fields: [
        { key: "planeKey", label: "Plane API Key", placeholder: "plane_api_xxxxxxxxxxxxxxxx", hint: "Plane → Settings → API Tokens" },
        { key: "workspace", label: "Workspace Slug", placeholder: "my-startup", hint: "From your Plane workspace URL" },
        { key: "projectId", label: "Project ID", placeholder: "xxxxxxxx-xxxx-xxxx", hint: "Plane → Project → Settings → General" },
      ],
    },
    {
      icon: "🐙",
      title: "Connect GitHub",
      desc: "Claude will open PRs here. You'll approve and merge.",
      fields: [
        { key: "githubToken", label: "Personal Access Token", placeholder: "ghp_xxxxxxxxxxxxxxxxxxxx", hint: "GitHub → Settings → Developer settings → Tokens" },
        { key: "repo", label: "Repository", placeholder: "yourorg/your-repo", hint: "e.g. neurabluAI/whai" },
      ],
    },
    {
      icon: "🤖",
      title: "Connect Anthropic",
      desc: "Powers the AI code reviewer on every pull request.",
      fields: [
        { key: "anthropicKey", label: "Anthropic API Key", placeholder: "sk-ant-xxxxxxxxxxxxxxxx", hint: "console.anthropic.com → API Keys" },
      ],
    },
  ];

  const current = steps[step];

  if (step === 3) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-8">
        <div className="bg-white rounded-2xl shadow-xl p-10 max-w-md w-full text-center">
          <div className="text-6xl mb-4">🎉</div>
          <h2 className="text-2xl font-bold text-slate-900 mb-2">You're all set!</h2>
          <p className="text-slate-500 mb-8">Your pipeline is connected. Write your first ticket and let Claude handle the development.</p>
          <button onClick={onDone} className="w-full bg-indigo-600 text-white py-3 rounded-xl font-semibold hover:bg-indigo-700 transition">
            Open Dashboard →
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-8">
      <div className="max-w-lg w-full">
        {/* Progress */}
        <div className="flex gap-2 mb-8 justify-center">
          {steps.map((s, i) => (
            <div key={i} className={`h-1.5 rounded-full flex-1 transition-all ${i <= step ? "bg-indigo-500" : "bg-slate-200"}`} />
          ))}
        </div>

        <div className="bg-white rounded-2xl shadow-xl p-8">
          <div className="text-4xl mb-3">{current.icon}</div>
          <h2 className="text-xl font-bold text-slate-900 mb-1">{current.title}</h2>
          <p className="text-slate-500 text-sm mb-6">{current.desc}</p>

          <div className="space-y-4">
            {current.fields.map((f) => (
              <div key={f.key}>
                <label className="block text-sm font-medium text-slate-700 mb-1">{f.label}</label>
                <input
                  type={f.key.toLowerCase().includes("key") || f.key.toLowerCase().includes("token") ? "password" : "text"}
                  value={vals[f.key]}
                  onChange={(e) => setVals({ ...vals, [f.key]: e.target.value })}
                  placeholder={f.placeholder}
                  className="w-full border border-slate-200 rounded-lg px-3 py-2.5 text-sm font-mono focus:outline-none focus:ring-2 focus:ring-indigo-400"
                />
                <p className="text-xs text-slate-400 mt-1">→ {f.hint}</p>
              </div>
            ))}
          </div>

          <div className="flex gap-3 mt-8">
            {step > 0 && (
              <button onClick={() => setStep(step - 1)} className="flex-1 border border-slate-200 text-slate-600 py-2.5 rounded-xl font-medium hover:bg-slate-50 transition">
                Back
              </button>
            )}
            <button onClick={() => setStep(step + 1)} className="flex-1 bg-indigo-600 text-white py-2.5 rounded-xl font-semibold hover:bg-indigo-700 transition">
              {step === steps.length - 1 ? "Finish setup" : "Continue →"}
            </button>
          </div>
        </div>

        <p className="text-center text-xs text-slate-400 mt-4">
          Your keys are stored locally in your browser only.
        </p>
      </div>
    </div>
  );
}

// ── Ticket Writer ─────────────────────────────────────────────────────────────

function TicketWriter({ onClose, onSave }) {
  const [stage, setStage] = useState("describe"); // describe | generating | review
  const [idea, setIdea] = useState("");
  const [ticket, setTicket] = useState(null);

  const EXAMPLE_TICKET = {
    title: "Add biometric authentication (Face ID / Touch ID)",
    type: "Feature",
    priority: "High",
    story: "As a returning user, I want to log in with Face ID so that I don't have to type my password every time.",
    criteria: [
      "Given the user has Face ID enabled on their device, when they open the app, then they are prompted to authenticate with Face ID",
      "Given Face ID authentication succeeds, then the user is taken to the home screen",
      "Given Face ID authentication fails, then a fallback to password login is shown",
      "Given the device does not support biometrics, then the biometric option is hidden",
    ],
    outOfScope: ["Setting up biometrics on the device", "Fingerprint on Android (separate ticket)"],
    context: "Use the `local_auth` Flutter package. Check `AuthService` in `lib/services/auth_service.dart`.",
  };

  const handleGenerate = () => {
    if (!idea.trim()) return;
    setStage("generating");
    setTimeout(() => {
      setTicket(EXAMPLE_TICKET);
      setStage("review");
    }, 2200);
  };

  return (
    <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-6" onClick={onClose}>
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between p-6 border-b border-slate-100">
          <div>
            <h2 className="font-bold text-slate-900 text-lg">Write a new ticket</h2>
            <p className="text-sm text-slate-500">Describe your feature idea — AI structures it for you</p>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600 text-xl font-light">✕</button>
        </div>

        <div className="p-6">
          {stage === "describe" && (
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Describe your idea in plain words</label>
              <textarea
                rows={5}
                value={idea}
                onChange={(e) => setIdea(e.target.value)}
                placeholder="e.g. I want users to be able to log in with Face ID so they don't have to type their password every time they open the app..."
                className="w-full border border-slate-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-400 resize-none"
              />
              <p className="text-xs text-slate-400 mt-2">Don't worry about technical details — just describe what you want users to be able to do.</p>
              <button
                onClick={handleGenerate}
                disabled={!idea.trim()}
                className="mt-4 w-full bg-indigo-600 text-white py-3 rounded-xl font-semibold hover:bg-indigo-700 disabled:opacity-40 disabled:cursor-not-allowed transition"
              >
                ✨ Structure with AI
              </button>
            </div>
          )}

          {stage === "generating" && (
            <div className="py-12 text-center">
              <div className="text-4xl mb-4 animate-pulse">🤖</div>
              <p className="font-semibold text-slate-700">Structuring your ticket…</p>
              <p className="text-sm text-slate-400 mt-1">Writing Acceptance Criteria and technical context</p>
            </div>
          )}

          {stage === "review" && ticket && (
            <div className="space-y-5">
              <div>
                <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wide mb-1">Title</label>
                <input
                  defaultValue={ticket.title}
                  className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm font-medium focus:outline-none focus:ring-2 focus:ring-indigo-400"
                />
              </div>

              <div className="flex gap-3">
                <div className="flex-1">
                  <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wide mb-1">Type</label>
                  <select className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none">
                    <option>Feature</option><option>Bug</option><option>Chore</option>
                  </select>
                </div>
                <div className="flex-1">
                  <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wide mb-1">Priority</label>
                  <select className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none">
                    <option>High</option><option>Medium</option><option>Low</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wide mb-1">User Story</label>
                <p className="text-sm text-slate-700 bg-slate-50 rounded-lg px-3 py-2.5">{ticket.story}</p>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wide mb-2">Acceptance Criteria</label>
                <div className="space-y-2">
                  {ticket.criteria.map((c, i) => (
                    <div key={i} className="flex items-start gap-2 bg-slate-50 rounded-lg px-3 py-2">
                      <span className="text-indigo-500 font-bold text-sm mt-0.5">AC{i + 1}</span>
                      <p className="text-sm text-slate-700 flex-1">{c}</p>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wide mb-1">Technical Context</label>
                <p className="text-sm text-slate-600 bg-slate-50 rounded-lg px-3 py-2.5 font-mono">{ticket.context}</p>
              </div>

              <div className="flex gap-3 pt-2">
                <button onClick={() => setStage("describe")} className="flex-1 border border-slate-200 text-slate-600 py-2.5 rounded-xl font-medium hover:bg-slate-50 transition text-sm">
                  ← Edit idea
                </button>
                <button
                  onClick={() => { onSave(ticket); onClose(); }}
                  className="flex-1 bg-indigo-600 text-white py-2.5 rounded-xl font-semibold hover:bg-indigo-700 transition text-sm"
                >
                  Send to Plane ✓
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ── Main Dashboard ────────────────────────────────────────────────────────────

const NAV = [
  { id: "dashboard", icon: "⬡", label: "Dashboard" },
  { id: "tickets", icon: "🗂️", label: "Tickets" },
  { id: "prs", icon: "🔀", label: "Pull Requests" },
  { id: "builds", icon: "📦", label: "Builds" },
  { id: "settings", icon: "⚙️", label: "Settings" },
];

function Dashboard({ onWriteTicket }) {
  const stats = [
    { label: "Tickets queued", value: "3", sub: "ready for Claude", icon: "🗂️", color: "indigo" },
    { label: "Open PRs", value: "3", sub: "2 awaiting your review", icon: "🔀", color: "blue" },
    { label: "Tests passing", value: "97%", sub: "last build", icon: "✅", color: "green" },
    { label: "Last build", value: "v0.3.1", sub: "2 days ago · iOS + Android", icon: "📦", color: "slate" },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-slate-900">Dashboard</h1>
          <p className="text-sm text-slate-500">WHAi · neurabluAI/why</p>
        </div>
        <button
          onClick={onWriteTicket}
          className="bg-indigo-600 text-white px-4 py-2 rounded-xl text-sm font-semibold hover:bg-indigo-700 transition flex items-center gap-2"
        >
          <span>✨</span> Write ticket
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 gap-4">
        {stats.map((s) => (
          <div key={s.label} className="bg-white rounded-xl border border-slate-100 p-4 shadow-sm">
            <div className="text-2xl mb-2">{s.icon}</div>
            <div className="text-2xl font-bold text-slate-900">{s.value}</div>
            <div className="text-xs font-medium text-slate-500 mt-0.5">{s.label}</div>
            <div className="text-xs text-slate-400">{s.sub}</div>
          </div>
        ))}
      </div>

      {/* Ticket queue */}
      <div>
        <h2 className="text-sm font-semibold text-slate-700 mb-3 flex items-center gap-2">
          🗂️ Ticket Queue
          <span className="text-xs text-slate-400 font-normal">Claude picks these up automatically</span>
        </h2>
        <div className="space-y-2">
          {MOCK_TICKETS.map((t) => (
            <div key={t.id} className="bg-white rounded-xl border border-slate-100 p-4 shadow-sm flex items-center gap-4">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-xs font-mono text-slate-400">{t.id}</span>
                  <Badge label={t.priority} color={priorityColor(t.priority)} />
                </div>
                <p className="text-sm font-medium text-slate-800 truncate">{t.title}</p>
                <p className="text-xs text-slate-400 mt-0.5">{t.criteria} acceptance criteria · {t.created}</p>
              </div>
              <Badge
                label={t.status}
                color={t.status === "To-Do" ? "indigo" : t.status === "In Progress" ? "yellow" : "blue"}
              />
            </div>
          ))}
        </div>
      </div>

      {/* PR Pipeline */}
      <div>
        <h2 className="text-sm font-semibold text-slate-700 mb-3 flex items-center gap-2">
          🔀 PR Pipeline
          <span className="text-xs text-slate-400 font-normal">Review and merge to ship</span>
        </h2>
        <div className="space-y-2">
          {MOCK_PRS.map((pr) => (
            <div key={pr.id} className="bg-white rounded-xl border border-slate-100 p-4 shadow-sm">
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-xs font-mono text-slate-400">{pr.id}</span>
                    <span className="text-xs font-mono text-slate-400">{pr.ticket}</span>
                  </div>
                  <p className="text-sm font-medium text-slate-800">{pr.title}</p>
                  <p className="text-xs font-mono text-slate-400 mt-0.5 truncate">{pr.branch}</p>
                </div>
                <div className="flex flex-col items-end gap-1.5 shrink-0">
                  <CiDot status={pr.ci} />
                  <Badge label={pr.aiReview} color={reviewColor(pr.aiReview)} />
                </div>
              </div>
              {pr.aiReview === "APPROVED" && (
                <div className="mt-3 pt-3 border-t border-slate-50 flex justify-end">
                  <button className="bg-emerald-500 text-white text-xs px-3 py-1.5 rounded-lg font-semibold hover:bg-emerald-600 transition">
                    Merge to main →
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function Tickets({ onWriteTicket }) {
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-bold text-slate-900">Tickets</h1>
        <button onClick={onWriteTicket} className="bg-indigo-600 text-white px-4 py-2 rounded-xl text-sm font-semibold hover:bg-indigo-700 transition">
          ✨ Write ticket
        </button>
      </div>
      {MOCK_TICKETS.map((t) => (
        <div key={t.id} className="bg-white rounded-xl border border-slate-100 p-5 shadow-sm">
          <div className="flex items-start justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <span className="text-xs font-mono text-slate-400">{t.id}</span>
                <Badge label={t.priority} color={priorityColor(t.priority)} />
                <Badge label="ai_dev" color="indigo" />
              </div>
              <p className="font-semibold text-slate-800">{t.title}</p>
              <p className="text-sm text-slate-400 mt-1">{t.criteria} acceptance criteria · Created {t.created}</p>
            </div>
            <Badge
              label={t.status}
              color={t.status === "To-Do" ? "indigo" : t.status === "In Progress" ? "yellow" : "blue"}
            />
          </div>
        </div>
      ))}
    </div>
  );
}

function PullRequests() {
  return (
    <div className="space-y-4">
      <h1 className="text-xl font-bold text-slate-900">Pull Requests</h1>
      {MOCK_PRS.map((pr) => (
        <div key={pr.id} className="bg-white rounded-xl border border-slate-100 p-5 shadow-sm space-y-3">
          <div className="flex items-start justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <span className="text-xs font-mono text-slate-400">{pr.id}</span>
                <span className="text-xs font-mono text-slate-400">{pr.ticket}</span>
              </div>
              <p className="font-semibold text-slate-800">{pr.title}</p>
              <p className="text-xs font-mono text-indigo-500 mt-1">{pr.branch}</p>
            </div>
            <div className="flex flex-col items-end gap-2">
              <CiDot status={pr.ci} />
              <Badge label={`AI: ${pr.aiReview}`} color={reviewColor(pr.aiReview)} />
            </div>
          </div>
          <div className="flex items-center justify-between pt-2 border-t border-slate-50">
            <span className="text-xs text-slate-400">by {pr.author} · {pr.updated}</span>
            <div className="flex gap-2">
              <button className="border border-slate-200 text-slate-600 text-xs px-3 py-1.5 rounded-lg hover:bg-slate-50 transition">
                View on GitHub
              </button>
              {pr.aiReview === "APPROVED" && pr.ci === "passing" && (
                <button className="bg-emerald-500 text-white text-xs px-3 py-1.5 rounded-lg font-semibold hover:bg-emerald-600 transition">
                  Merge →
                </button>
              )}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

function Builds() {
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-bold text-slate-900">Builds</h1>
        <button className="border border-slate-200 text-slate-600 px-4 py-2 rounded-xl text-sm font-medium hover:bg-slate-50 transition">
          🏷️ Tag new release
        </button>
      </div>
      <div className="bg-white rounded-xl border border-slate-100 shadow-sm overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-slate-100 bg-slate-50">
              <th className="text-left px-5 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wide">Version</th>
              <th className="text-left px-5 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wide">iOS</th>
              <th className="text-left px-5 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wide">Android</th>
              <th className="text-left px-5 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wide">Date</th>
            </tr>
          </thead>
          <tbody>
            {MOCK_BUILDS.map((b) => (
              <tr key={b.version} className="border-b border-slate-50 last:border-0 hover:bg-slate-50/50">
                <td className="px-5 py-3.5 font-mono font-semibold text-indigo-600">{b.version}</td>
                <td className="px-5 py-3.5">
                  <span className={b.ios === "✓" ? "text-emerald-500 font-bold" : "text-red-400 font-bold"}>{b.ios === "✓" ? "✓ IPA ready" : "✗ Failed"}</span>
                </td>
                <td className="px-5 py-3.5">
                  <span className={b.android === "✓" ? "text-emerald-500 font-bold" : "text-red-400 font-bold"}>{b.android === "✓" ? "✓ AAB ready" : "✗ Failed"}</span>
                </td>
                <td className="px-5 py-3.5 text-slate-400">{b.date}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <p className="text-xs text-slate-400 text-center">Artifacts are available in GitHub Actions for 30 days after each build.</p>
    </div>
  );
}

function Settings({ onReset }) {
  return (
    <div className="space-y-6">
      <h1 className="text-xl font-bold text-slate-900">Settings</h1>
      {[
        { label: "Plane.so", icon: "🗂️", fields: ["API Key", "Workspace", "Project ID"] },
        { label: "GitHub", icon: "🐙", fields: ["Personal Access Token", "Repository"] },
        { label: "Anthropic", icon: "🤖", fields: ["API Key"] },
      ].map((section) => (
        <div key={section.label} className="bg-white rounded-xl border border-slate-100 p-5 shadow-sm">
          <h2 className="font-semibold text-slate-800 mb-4 flex items-center gap-2">
            <span>{section.icon}</span> {section.label}
            <Badge label="Connected" color="green" />
          </h2>
          <div className="space-y-3">
            {section.fields.map((f) => (
              <div key={f}>
                <label className="block text-xs font-medium text-slate-500 mb-1">{f}</label>
                <input
                  type={f.toLowerCase().includes("key") || f.toLowerCase().includes("token") ? "password" : "text"}
                  defaultValue="••••••••••••••••"
                  className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm font-mono focus:outline-none focus:ring-2 focus:ring-indigo-400"
                />
              </div>
            ))}
          </div>
        </div>
      ))}
      <button onClick={onReset} className="text-sm text-red-500 hover:text-red-700">
        Reset and run setup wizard again
      </button>
    </div>
  );
}

// ── App Shell ─────────────────────────────────────────────────────────────────

export default function App() {
  const [setup, setSetup] = useState(false); // start at false to show dashboard directly
  const [showSetup, setShowSetup] = useState(false);
  const [activeNav, setActiveNav] = useState("dashboard");
  const [showTicketWriter, setShowTicketWriter] = useState(false);
  const [tickets, setTickets] = useState(MOCK_TICKETS);
  const [notification, setNotification] = useState(null);

  const notify = (msg) => {
    setNotification(msg);
    setTimeout(() => setNotification(null), 3000);
  };

  const handleSaveTicket = (t) => {
    setTickets([{ id: `TICKET-${tickets.length + 10}`, title: t.title, priority: "High", status: "To-Do", label: "ai_dev", created: "Just now", criteria: t.criteria?.length || 4 }, ...tickets]);
    notify("Ticket sent to Plane ✓ Claude will pick it up shortly");
  };

  if (showSetup) return <SetupWizard onDone={() => { setShowSetup(false); setSetup(false); }} />;
  if (setup) return <SetupWizard onDone={() => setSetup(false)} />;

  const renderPage = () => {
    switch (activeNav) {
      case "dashboard": return <Dashboard onWriteTicket={() => setShowTicketWriter(true)} />;
      case "tickets": return <Tickets onWriteTicket={() => setShowTicketWriter(true)} />;
      case "prs": return <PullRequests />;
      case "builds": return <Builds />;
      case "settings": return <Settings onReset={() => setShowSetup(true)} />;
      default: return null;
    }
  };

  return (
    <div className="flex h-screen bg-slate-50 font-sans overflow-hidden">
      {/* Sidebar */}
      <aside className="w-56 bg-slate-900 flex flex-col shrink-0">
        <div className="px-5 py-5 border-b border-slate-800">
          <div className="text-white font-bold text-base leading-tight">Story → Store</div>
          <div className="text-slate-400 text-xs mt-0.5">by NeuraBlu AI</div>
        </div>

        <nav className="flex-1 px-3 py-4 space-y-0.5">
          {NAV.map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveNav(item.id)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition ${
                activeNav === item.id
                  ? "bg-indigo-600 text-white"
                  : "text-slate-400 hover:text-white hover:bg-slate-800"
              }`}
            >
              <span className="text-base">{item.icon}</span>
              {item.label}
            </button>
          ))}
        </nav>

        <div className="px-5 py-4 border-t border-slate-800">
          <button
            onClick={() => setShowTicketWriter(true)}
            className="w-full bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-semibold py-2.5 rounded-xl transition"
          >
            ✨ Write ticket
          </button>
        </div>
      </aside>

      {/* Main content */}
      <main className="flex-1 overflow-y-auto">
        <div className="max-w-2xl mx-auto p-6">
          {renderPage()}
        </div>
      </main>

      {/* Ticket writer modal */}
      {showTicketWriter && (
        <TicketWriter
          onClose={() => setShowTicketWriter(false)}
          onSave={handleSaveTicket}
        />
      )}

      {/* Notification toast */}
      {notification && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 bg-slate-900 text-white text-sm px-5 py-3 rounded-xl shadow-xl z-50 font-medium">
          {notification}
        </div>
      )}
    </div>
  );
}
